import { useState } from "react";

const G = {
  bg: "#0a1628",
  card: "rgba(255,255,255,0.04)",
  border: "rgba(255,255,255,0.1)",
  accent: "#f59e0b",
  accentLight: "#fcd34d",
  blue: "#3b82f6",
  teal: "#14b8a6",
  text: "#f1f5f9",
  muted: "#94a3b8",
  green: "#22c55e",
};

const styles = {
  app: {
    minHeight: "100vh",
    background: `radial-gradient(ellipse at 20% 10%, #1e3a5f 0%, ${G.bg} 60%)`,
    fontFamily: "'Palatino Linotype', 'Book Antiqua', Palatino, serif",
    color: G.text,
  },
  header: {
    borderBottom: `1px solid ${G.border}`,
    padding: "0 24px",
    background: "rgba(0,0,0,0.3)",
    backdropFilter: "blur(12px)",
    position: "sticky",
    top: 0,
    zIndex: 100,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    height: "64px",
  },
  logo: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  logoIcon: {
    width: "36px",
    height: "36px",
    background: `linear-gradient(135deg, ${G.accent}, ${G.teal})`,
    borderRadius: "8px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    fontSize: "18px",
  },
  logoText: {
    fontSize: "18px",
    fontWeight: "800",
    color: G.text,
    letterSpacing: "-0.02em",
  },
  logoSub: {
    fontSize: "11px",
    color: G.muted,
    letterSpacing: "0.15em",
    textTransform: "uppercase",
  },
  badge: {
    background: `rgba(245,158,11,0.15)`,
    border: `1px solid rgba(245,158,11,0.3)`,
    color: G.accent,
    fontSize: "11px",
    padding: "3px 10px",
    borderRadius: "20px",
    fontFamily: "monospace",
  },
  main: { maxWidth: "860px", margin: "0 auto", padding: "32px 20px 60px" },
  sectionTitle: {
    fontSize: "11px",
    fontWeight: "700",
    letterSpacing: "0.12em",
    textTransform: "uppercase",
    color: G.accent,
    marginBottom: "14px",
    display: "flex",
    alignItems: "center",
    gap: "8px",
  },
  card: {
    background: G.card,
    border: `1px solid ${G.border}`,
    borderRadius: "14px",
    padding: "24px",
    marginBottom: "20px",
  },
  grid2: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" },
  grid3: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "16px" },
  label: {
    display: "block",
    fontSize: "11px",
    fontWeight: "700",
    letterSpacing: "0.1em",
    textTransform: "uppercase",
    color: G.teal,
    marginBottom: "6px",
  },
  input: {
    width: "100%",
    background: "rgba(255,255,255,0.06)",
    border: `1px solid rgba(255,255,255,0.15)`,
    borderRadius: "8px",
    color: G.text,
    padding: "10px 12px",
    fontSize: "14px",
    outline: "none",
    boxSizing: "border-box",
    fontFamily: "inherit",
    transition: "border-color 0.2s",
  },
  textarea: {
    width: "100%",
    background: "rgba(255,255,255,0.06)",
    border: `1px solid rgba(255,255,255,0.15)`,
    borderRadius: "8px",
    color: G.text,
    padding: "10px 12px",
    fontSize: "14px",
    outline: "none",
    boxSizing: "border-box",
    fontFamily: "inherit",
    resize: "vertical",
    minHeight: "70px",
  },
  btn: (disabled) => ({
    width: "100%",
    padding: "14px",
    borderRadius: "10px",
    border: "none",
    background: disabled
      ? "rgba(255,255,255,0.08)"
      : `linear-gradient(90deg, ${G.accent}, ${G.teal})`,
    color: disabled ? "rgba(255,255,255,0.3)" : "#000",
    fontSize: "15px",
    fontWeight: "800",
    letterSpacing: "0.04em",
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "opacity 0.2s",
    fontFamily: "inherit",
  }),
  divider: {
    border: "none",
    borderTop: `1px solid ${G.border}`,
    margin: "20px 0",
  },
};

// Lesson progression stages
const DEFAULT_STAGES = [
  { stage: "INTRODUCTION\n5 Minutes", teacher: "", learners: "", assessment: "" },
  { stage: "LESSON DEVELOPMENT\n10 Minutes", teacher: "", learners: "", assessment: "" },
  { stage: "Activity 1\n10 Minutes", teacher: "", learners: "", assessment: "" },
  { stage: "Activity 2\n15 Minutes", teacher: "", learners: "", assessment: "" },
  { stage: "EXERCISE\n20 Minutes", teacher: "", learners: "", assessment: "" },
  { stage: "CONCLUSION\n10 Minutes", teacher: "", learners: "", assessment: "" },
  { stage: "HOMEWORK", teacher: "", learners: "", assessment: "" },
];

export default function LundaLessonPlanAI() {
  const [form, setForm] = useState({
    school: "Mushindamo Girl Technical Secondary School",
    teacher: "",
    subject: "",
    level: "",
    time: "",
    duration: "80 Minutes",
    topic: "",
    subtopic: "",
    pupils: "",
    boys: "",
    girls: "",
    generalCompetences: "",
    specificCompetences: "",
    lessonGoal: "",
    priorKnowledge: "",
    references: "",
    envPhysical: "Classroom",
    envVirtual: "",
    envTech: "",
    materials: "",
    expectedStandard: "",
    lessonEvaluation: "",
  });

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const canGenerate = form.teacher && form.subject && form.topic && form.level;

  async function generate() {
    if (!canGenerate || loading) return;
    setLoading(true);
    setResult(null);
    setError("");

    const prompt = `You are an expert CBC (Competency-Based Curriculum) lesson plan writer for the Ministry of Education in Zambia.

Generate a complete CBC lesson plan in strict JSON format based on these details:

School: ${form.school}
Teacher: ${form.teacher}
Subject: ${form.subject}
Level: ${form.level}
Time: ${form.time || "08:00-09:00"}
Duration: ${form.duration}
Topic: ${form.topic}
Sub-topic: ${form.subtopic}
Number of Pupils: ${form.pupils || "50"}
Boys: ${form.boys || "25"} Girls: ${form.girls || "25"}
General Competences (user input): ${form.generalCompetences || "generate 3 appropriate general competences"}
Specific Competences: ${form.specificCompetences || "generate 2 specific competences"}
Lesson Goal: ${form.lessonGoal || "generate an appropriate lesson goal"}
Prior Knowledge: ${form.priorKnowledge || "generate appropriate prior knowledge"}
References: ${form.references || "generate relevant references"}
Learning Environment - Physical: ${form.envPhysical}
Learning Environment - Virtual: ${form.envVirtual || "Online platforms"}
Learning Environment - Technological: ${form.envTech || "Laptops, tablets, projector, smartphones"}
Teaching & Learning Materials: ${form.materials || "generate appropriate materials list"}
Expected Standard: ${form.expectedStandard || "generate expected standard"}
Lesson Evaluation: ${form.lessonEvaluation || "generate a lesson evaluation criteria statement"}

Return ONLY a valid JSON object with this exact structure (no markdown, no backticks, no extra text):
{
  "generalCompetences": ["competence 1", "competence 2", "competence 3"],
  "specificCompetences": ["competence 1"],
  "lessonGoal": "full lesson goal statement",
  "priorKnowledge": ["item 1"],
  "references": ["ref 1", "ref 2"],
  "envPhysical": "Classroom, ICT Laboratory",
  "envVirtual": "Online platforms",
  "envTech": "Laptops, tablets, projector",
  "materials": ["item 1", "item 2", "item 3", "item 4", "item 5"],
  "expectedStandard": "expected standard statement",
  "progression": [
    {
      "stage": "INTRODUCTION\n5 Minutes",
      "teacher": "detailed teacher role description",
      "learners": "detailed learners role description",
      "assessment": "assessment criteria"
    },
    {
      "stage": "LESSON DEVELOPMENT\n10 Minutes",
      "teacher": "detailed teacher role",
      "learners": "detailed learners role",
      "assessment": "assessment criteria"
    },
    {
      "stage": "Activity 1: [Name]\n10 Minutes",
      "teacher": "detailed teacher role",
      "learners": "detailed learners role",
      "assessment": "assessment criteria"
    },
    {
      "stage": "Activity 2: [Name]\n15 Minutes",
      "teacher": "detailed teacher role",
      "learners": "detailed learners role",
      "assessment": "assessment criteria"
    },
    {
      "stage": "EXERCISE\n20 Minutes",
      "teacher": "detailed teacher role",
      "learners": "detailed learners role",
      "assessment": "assessment criteria"
    },
    {
      "stage": "CONCLUSION\n10 Minutes",
      "teacher": "detailed teacher role",
      "learners": "detailed learners role",
      "assessment": "assessment criteria"
    },
    {
      "stage": "HOMEWORK",
      "teacher": "homework task description",
      "learners": "what learners do at home",
      "assessment": "evidence of completion"
    }
  ],
  "lessonEvaluation": "lesson evaluation statement"
}`;

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      const data = await res.json();
      const raw = data.content?.map((b) => b.text || "").join("") || "";
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setResult(parsed);
    } catch (e) {
      setError("Failed to generate lesson plan. Please try again.");
    }
    setLoading(false);
  }

  function copyText() {
    if (!result) return;
    const txt = buildPlainText(result);
    navigator.clipboard.writeText(txt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function buildPlainText(r) {
    const lines = [
      "MINISTRY OF EDUCATION",
      `${form.school.toUpperCase()}`,
      "LESSON PLAN",
      `SUBJECT: ${form.subject}    TEACHER: ${form.teacher}    TIME: ${form.time}`,
      `LEVEL: ${form.level}    DURATION: ${form.duration}`,
      `TOPIC: ${form.topic}    NO. OF PUPILS: ${form.pupils}`,
      `SUB-TOPIC: ${form.subtopic}    BOYS: ${form.boys}    GIRLS: ${form.girls}`,
      "",
      "GENERAL COMPETENCES:",
      ...(r.generalCompetences || []).map((c) => `  • ${c}`),
      "",
      "SPECIFIC COMPETENCES:",
      ...(r.specificCompetences || []).map((c) => `  • ${c}`),
      "",
      `LESSON GOAL: ${r.lessonGoal}`,
      "",
      "PRIOR KNOWLEDGE:",
      ...(r.priorKnowledge || []).map((p) => `  • ${p}`),
      "",
      "REFERENCES:",
      ...(r.references || []).map((ref) => `  • ${ref}`),
      "",
      "LEARNING ENVIRONMENT",
      `  Physical: ${r.envPhysical}`,
      `  Virtual: ${r.envVirtual}`,
      `  Technological: ${r.envTech}`,
      "",
      "TEACHING AND LEARNING MATERIALS/RESOURCES:",
      ...(r.materials || []).map((m) => `  • ${m}`),
      "",
      `EXPECTED STANDARD: ${r.expectedStandard}`,
      "",
      "LESSON PROGRESSION",
      "STAGES | TEACHER'S ROLE | LEARNERS' ROLE | ASSESSMENT CRITERIA",
      ...(r.progression || []).map(
        (p) => `${p.stage} | ${p.teacher} | ${p.learners} | ${p.assessment}`
      ),
      "",
      `LESSON EVALUATION: ${r.lessonEvaluation}`,
    ];
    return lines.join("\n");
  }

  async function downloadWord() {
    if (!result || downloading) return;
    setDownloading(true);
    try {
      // Dynamically load docx from CDN
      await new Promise((resolve, reject) => {
        if (window.docx) { resolve(); return; }
        const s = document.createElement("script");
        s.src = "https://cdnjs.cloudflare.com/ajax/libs/docx/8.5.0/docx.umd.min.js";
        s.onload = resolve; s.onerror = reject;
        document.head.appendChild(s);
      });
      const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
              AlignmentType, WidthType, BorderStyle, ShadingType, VerticalAlign,
              LevelFormat } = window.docx;

      const border = { style: BorderStyle.SINGLE, size: 1, color: "AAAAAA" };
      const cellBorders = { top: border, bottom: border, left: border, right: border };
      const cellMargins = { top: 80, bottom: 80, left: 120, right: 120 };

      const headingRun = (text) => new TextRun({ text, bold: true, size: 22, font: "Arial" });
      const boldRun = (text) => new TextRun({ text, bold: true, size: 20, font: "Arial" });
      const normalRun = (text) => new TextRun({ text, size: 20, font: "Arial" });
      const para = (children, opts = {}) => new Paragraph({ children, ...opts });
      const bulletPara = (text) => new Paragraph({
        numbering: { reference: "bullets", level: 0 },
        children: [normalRun(text)],
      });
      const sectionHeader = (text) => para([headingRun(text)], {
        spacing: { before: 160, after: 60 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "2E75B6", space: 1 } },
      });

      // Table for Lesson Progression
      const tableRows = [
        new TableRow({
          tableHeader: true,
          children: ["STAGES", "TEACHER'S ROLE", "LEARNERS' ROLE", "ASSESSMENT CRITERIA"].map(h =>
            new TableCell({
              borders: cellBorders, margins: cellMargins,
              width: { size: 2250, type: WidthType.DXA },
              shading: { fill: "D5E8F0", type: ShadingType.CLEAR },
              children: [para([boldRun(h)])],
            })
          ),
        }),
        ...(result.progression || []).map((row, i) =>
          new TableRow({
            children: [row.stage.replace("\n", " "), row.teacher, row.learners, row.assessment].map((cell, j) =>
              new TableCell({
                borders: cellBorders, margins: cellMargins,
                width: { size: 2250, type: WidthType.DXA },
                shading: { fill: i % 2 === 0 ? "F5F5F5" : "FFFFFF", type: ShadingType.CLEAR },
                children: [para([j === 0 ? boldRun(cell) : normalRun(cell)])],
              })
            ),
          })
        ),
      ];

      const doc = new Document({
        numbering: {
          config: [{
            reference: "bullets",
            levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT,
              style: { paragraph: { indent: { left: 720, hanging: 360 } } } }],
          }],
        },
        sections: [{
          properties: {
            page: { size: { width: 11906, height: 16838 }, margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 } }
          },
          children: [
            // Title block
            para([new TextRun({ text: "MINISTRY OF EDUCATION", bold: true, size: 26, font: "Arial" })], { alignment: AlignmentType.CENTER }),
            para([new TextRun({ text: form.school.toUpperCase(), bold: true, size: 28, font: "Arial" })], { alignment: AlignmentType.CENTER }),
            para([new TextRun({ text: "LESSON PLAN", bold: true, size: 24, font: "Arial" })], { alignment: AlignmentType.CENTER, spacing: { after: 200 } }),

            // Info grid
            para([boldRun("SUBJECT: "), normalRun(form.subject + "    "), boldRun("TEACHER: "), normalRun(form.teacher + "    "), boldRun("TIME: "), normalRun(form.time)]),
            para([boldRun("LEVEL: "), normalRun(form.level + "    "), boldRun("DURATION: "), normalRun(form.duration)]),
            para([boldRun("TOPIC: "), normalRun(form.topic + "    "), boldRun("NO. OF PUPILS: "), normalRun(form.pupils)]),
            para([boldRun("SUB-TOPIC: "), normalRun(form.subtopic + "    "), boldRun("BOYS: "), normalRun(form.boys + "    "), boldRun("GIRLS: "), normalRun(form.girls)], { spacing: { after: 160 } }),

            // General Competences
            sectionHeader("GENERAL COMPETENCES:"),
            ...(result.generalCompetences || []).map(c => bulletPara(c)),

            // Specific Competences
            sectionHeader("SPECIFIC COMPETENCES:"),
            ...(result.specificCompetences || []).map(c => bulletPara(c)),

            // Lesson Goal
            sectionHeader("LESSON GOAL:"),
            para([normalRun(result.lessonGoal)], { spacing: { after: 80 } }),

            // Prior Knowledge
            sectionHeader("PRIOR KNOWLEDGE:"),
            ...(result.priorKnowledge || []).map(p => bulletPara(p)),

            // References
            sectionHeader("REFERENCES:"),
            ...(result.references || []).map(r => bulletPara(r)),

            // Learning Environment
            sectionHeader("LEARNING ENVIRONMENT"),
            para([boldRun("Physical: "), normalRun(result.envPhysical)]),
            para([boldRun("Virtual: "), normalRun(result.envVirtual)]),
            para([boldRun("Technological: "), normalRun(result.envTech)], { spacing: { after: 80 } }),

            // Materials
            sectionHeader("TEACHING AND LEARNING MATERIALS/RESOURCES:"),
            ...(result.materials || []).map(m => bulletPara(m)),

            // Expected Standard
            sectionHeader("EXPECTED STANDARD:"),
            para([normalRun(result.expectedStandard)], { spacing: { after: 160 } }),

            // Lesson Progression
            sectionHeader("LESSON PROGRESSION"),
            new Table({
              width: { size: 9000, type: WidthType.DXA },
              columnWidths: [2250, 2250, 2250, 2250],
              rows: tableRows,
            }),

            // Lesson Evaluation
            sectionHeader("LESSON EVALUATION:"),
            para([normalRun(result.lessonEvaluation)]),
          ],
        }],
      });

      const buffer = await Packer.toBlob(doc);
      const url = URL.createObjectURL(buffer);
      const a = document.createElement("a");
      a.href = url;
      a.download = `Lesson_Plan_${form.subject}_${form.topic}.docx`.replace(/\s+/g, "_");
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error(e);
      alert("Download failed. Please try again.");
    }
    setDownloading(false);
  }

  const F = ({ label, k, placeholder, span = 1, area = false }) => (
    <div style={{ gridColumn: `span ${span}` }}>
      <label style={styles.label}>{label}</label>
      {area ? (
        <textarea
          style={styles.textarea}
          placeholder={placeholder}
          value={form[k]}
          onChange={(e) => set(k, e.target.value)}
        />
      ) : (
        <input
          style={styles.input}
          placeholder={placeholder}
          value={form[k]}
          onChange={(e) => set(k, e.target.value)}
        />
      )}
    </div>
  );

  return (
    <div style={styles.app}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.logo}>
          <div style={styles.logoIcon}>📘</div>
          <div>
            <div style={styles.logoText}>Lunda Lesson Plan AI</div>
            <div style={styles.logoSub}>CBC — Ministry of Education Format</div>
          </div>
        </div>
        <span style={styles.badge}>Zambia CBC</span>
      </header>

      <main style={styles.main}>
        {/* Intro */}
        <div style={{ textAlign: "center", marginBottom: "32px" }}>
          <h1 style={{ fontSize: "26px", fontWeight: "800", margin: "0 0 8px", color: G.text }}>
            Generate Your CBC Lesson Plan
          </h1>
          <p style={{ color: G.muted, margin: 0, fontSize: "14px" }}>
            Fill in what you know — AI will complete the rest in official Ministry of Education format.
          </p>
        </div>

        {/* Section 1: School Info */}
        <div style={styles.card}>
          <div style={styles.sectionTitle}>🏫 School & Teacher Information</div>
          <div style={styles.grid2}>
            <F label="School Name" k="school" placeholder="e.g. Maputosa Secondary School" />
            <F label="Teacher's Name" k="teacher" placeholder="Full name" />
            <F label="Subject" k="subject" placeholder="e.g. ICT, Mathematics, Science" />
            <F label="Level / Class" k="level" placeholder="e.g. Form 1 K" />
            <F label="Time" k="time" placeholder="e.g. 08:20 - 09:40" />
            <F label="Duration" k="duration" placeholder="e.g. 80 Minutes" />
          </div>
        </div>

        {/* Section 2: Topic */}
        <div style={styles.card}>
          <div style={styles.sectionTitle}>📖 Topic Details</div>
          <div style={styles.grid2}>
            <F label="Topic" k="topic" placeholder="e.g. 1.3 File Management" />
            <F label="Sub-topic" k="subtopic" placeholder="e.g. 1.3.1 Basics of File Management" />
            <F label="No. of Pupils" k="pupils" placeholder="e.g. 50" />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
              <div>
                <label style={styles.label}>Boys</label>
                <input style={styles.input} placeholder="25" value={form.boys} onChange={e => set("boys", e.target.value)} />
              </div>
              <div>
                <label style={styles.label}>Girls</label>
                <input style={styles.input} placeholder="25" value={form.girls} onChange={e => set("girls", e.target.value)} />
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Competences */}
        <div style={styles.card}>
          <div style={styles.sectionTitle}>🎯 Competences & Goals</div>
          <div style={{ display: "grid", gap: "16px" }}>
            <F label="General Competences (leave blank to auto-generate)" k="generalCompetences" placeholder="e.g. Demonstrate ability to organize files..." area span={2} />
            <F label="Specific Competences (leave blank to auto-generate)" k="specificCompetences" placeholder="e.g. 1.3.1.1 Use different file naming conventions" area span={2} />
            <F label="Lesson Goal (leave blank to auto-generate)" k="lessonGoal" placeholder="By the end of this lesson, learners should..." area span={2} />
            <F label="Prior Knowledge (leave blank to auto-generate)" k="priorKnowledge" placeholder="e.g. Learners familiar with categorizing objects" area span={2} />
          </div>
        </div>

        {/* Section 4: Environment & Materials */}
        <div style={styles.card}>
          <div style={styles.sectionTitle}>🌍 Learning Environment & Resources</div>
          <div style={styles.grid3}>
            <F label="Physical Environment" k="envPhysical" placeholder="e.g. Classroom, ICT Lab" />
            <F label="Virtual Environment" k="envVirtual" placeholder="e.g. Online platforms" />
            <F label="Technological" k="envTech" placeholder="e.g. Laptops, projector" />
          </div>
          <div style={{ marginTop: "16px" }}>
            <F label="Teaching & Learning Materials (leave blank to auto-generate)" k="materials" placeholder="e.g. Computers, projector, printed guides..." area />
          </div>
          <div style={{ marginTop: "16px" }}>
            <F label="References (leave blank to auto-generate)" k="references" placeholder="e.g. ICT Module 2, Term 2 (2023 Curriculum)" area />
          </div>
          <div style={{ marginTop: "16px" }}>
            <F label="Expected Standard (leave blank to auto-generate)" k="expectedStandard" placeholder="e.g. File naming conventions used appropriately" />
          </div>
        </div>

        {/* Generate Button */}
        <button style={styles.btn(!canGenerate || loading)} onClick={generate} disabled={!canGenerate || loading}>
          {loading ? "✨ Generating CBC Lesson Plan..." : "✨ Generate CBC Lesson Plan"}
        </button>
        {!canGenerate && (
          <p style={{ color: G.muted, fontSize: "12px", textAlign: "center", marginTop: "8px" }}>
            Teacher, Subject, Topic, and Level are required
          </p>
        )}

        {error && (
          <div style={{ ...styles.card, borderColor: "rgba(239,68,68,0.4)", background: "rgba(239,68,68,0.08)", marginTop: "20px" }}>
            <p style={{ color: "#fca5a5", margin: 0 }}>⚠️ {error}</p>
          </div>
        )}

        {loading && (
          <div style={{ ...styles.card, marginTop: "20px" }}>
            {[100, 70, 90, 60, 80, 50].map((w, i) => (
              <div key={i} style={{ height: "13px", borderRadius: "6px", background: "rgba(255,255,255,0.07)", width: `${w}%`, marginBottom: "12px", animation: "pulse 1.5s infinite", animationDelay: `${i * 0.1}s` }} />
            ))}
            <style>{`@keyframes pulse{0%,100%{opacity:.3}50%{opacity:.8}}`}</style>
          </div>
        )}

        {/* RESULT */}
        {result && !loading && (
          <div style={{ marginTop: "28px" }}>
            {/* Header bar */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h2 style={{ color: G.accentLight, fontSize: "18px", margin: 0, fontWeight: "800" }}>📄 Generated Lesson Plan</h2>
              <div style={{ display: "flex", gap: "8px" }}>
                <button onClick={copyText} style={{ background: copied ? `rgba(34,197,94,0.15)` : "rgba(255,255,255,0.07)", border: `1px solid ${copied ? "rgba(34,197,94,0.4)" : G.border}`, color: copied ? G.green : G.muted, borderRadius: "8px", padding: "6px 16px", cursor: "pointer", fontSize: "13px", fontFamily: "inherit" }}>
                  {copied ? "✓ Copied!" : "Copy Text"}
                </button>
                <button onClick={downloadWord} disabled={downloading} style={{ background: downloading ? "rgba(255,255,255,0.05)" : "rgba(59,130,246,0.15)", border: `1px solid ${downloading ? G.border : "rgba(59,130,246,0.4)"}`, color: downloading ? G.muted : "#93c5fd", borderRadius: "8px", padding: "6px 16px", cursor: downloading ? "not-allowed" : "pointer", fontSize: "13px", fontFamily: "inherit", fontWeight: "600" }}>
                  {downloading ? "⏳ Downloading..." : "⬇️ Download Word"}
                </button>
              </div>
            </div>

            {/* Ministry Header */}
            <div style={{ ...styles.card, textAlign: "center", borderColor: `rgba(245,158,11,0.3)`, background: "rgba(245,158,11,0.05)" }}>
              <p style={{ margin: "0 0 2px", fontSize: "13px", fontWeight: "700", color: G.accent, letterSpacing: "0.1em" }}>MINISTRY OF EDUCATION</p>
              <p style={{ margin: "0 0 2px", fontSize: "15px", fontWeight: "800", color: G.text }}>{form.school.toUpperCase()}</p>
              <p style={{ margin: "0 0 12px", fontSize: "13px", fontWeight: "700", color: G.accent, letterSpacing: "0.1em" }}>LESSON PLAN</p>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "4px 24px", textAlign: "left", fontSize: "13px", color: G.muted, maxWidth: "500px", margin: "0 auto" }}>
                <span><b style={{ color: G.text }}>SUBJECT:</b> {form.subject}</span>
                <span><b style={{ color: G.text }}>TEACHER:</b> {form.teacher}</span>
                <span><b style={{ color: G.text }}>LEVEL:</b> {form.level}</span>
                <span><b style={{ color: G.text }}>TIME:</b> {form.time}</span>
                <span><b style={{ color: G.text }}>TOPIC:</b> {form.topic}</span>
                <span><b style={{ color: G.text }}>DURATION:</b> {form.duration}</span>
                <span><b style={{ color: G.text }}>SUB-TOPIC:</b> {form.subtopic}</span>
                <span><b style={{ color: G.text }}>PUPILS:</b> {form.pupils} (B:{form.boys} G:{form.girls})</span>
              </div>
            </div>

            {/* Competences */}
            <div style={styles.card}>
              <Section title="GENERAL COMPETENCES" items={result.generalCompetences} />
              <hr style={styles.divider} />
              <Section title="SPECIFIC COMPETENCES" items={result.specificCompetences} />
              <hr style={styles.divider} />
              <InfoRow label="LESSON GOAL" value={result.lessonGoal} />
              <hr style={styles.divider} />
              <Section title="PRIOR KNOWLEDGE" items={result.priorKnowledge} />
              <hr style={styles.divider} />
              <Section title="REFERENCES" items={result.references} />
            </div>

            {/* Environment */}
            <div style={styles.card}>
              <p style={styles.sectionTitle}>🌍 LEARNING ENVIRONMENT</p>
              <div style={{ display: "grid", gap: "8px", fontSize: "14px", color: G.muted }}>
                <span><b style={{ color: G.teal }}>Physical:</b> {result.envPhysical}</span>
                <span><b style={{ color: G.teal }}>Virtual:</b> {result.envVirtual}</span>
                <span><b style={{ color: G.teal }}>Technological:</b> {result.envTech}</span>
              </div>
              <hr style={styles.divider} />
              <Section title="TEACHING AND LEARNING MATERIALS/RESOURCES" items={result.materials} />
              <hr style={styles.divider} />
              <InfoRow label="EXPECTED STANDARD" value={result.expectedStandard} />
            </div>

            {/* Lesson Progression Table */}
            <div style={styles.card}>
              <p style={styles.sectionTitle}>📋 LESSON PROGRESSION</p>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px" }}>
                  <thead>
                    <tr>
                      {["STAGES", "TEACHER'S ROLE", "LEARNERS' ROLE", "ASSESSMENT CRITERIA"].map((h) => (
                        <th key={h} style={{ background: "rgba(245,158,11,0.15)", color: G.accent, padding: "10px 12px", textAlign: "left", border: `1px solid ${G.border}`, fontWeight: "800", fontSize: "11px", letterSpacing: "0.08em" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(result.progression || []).map((row, i) => (
                      <tr key={i} style={{ background: i % 2 === 0 ? "rgba(255,255,255,0.02)" : "transparent" }}>
                        {[row.stage, row.teacher, row.learners, row.assessment].map((cell, j) => (
                          <td key={j} style={{ padding: "10px 12px", border: `1px solid ${G.border}`, color: j === 0 ? G.accentLight : G.muted, verticalAlign: "top", whiteSpace: j === 0 ? "pre-line" : "normal", fontWeight: j === 0 ? "700" : "400", lineHeight: "1.6" }}>{cell}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Evaluation */}
            <div style={{ ...styles.card, borderColor: `rgba(20,184,166,0.3)`, background: "rgba(20,184,166,0.05)" }}>
              <p style={{ ...styles.sectionTitle, color: G.teal }}>📝 LESSON EVALUATION</p>
              <p style={{ color: G.muted, fontSize: "14px", lineHeight: "1.7", margin: 0 }}>{result.lessonEvaluation}</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function Section({ title, items }) {
  return (
    <div style={{ marginBottom: "4px" }}>
      <p style={{ fontSize: "12px", fontWeight: "800", letterSpacing: "0.1em", color: "#f59e0b", margin: "0 0 8px", textTransform: "uppercase" }}>{title}</p>
      <ul style={{ margin: 0, paddingLeft: "20px" }}>
        {(items || []).map((item, i) => (
          <li key={i} style={{ color: "#94a3b8", fontSize: "14px", marginBottom: "4px", lineHeight: "1.6" }}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

function InfoRow({ label, value }) {
  return (
    <div>
      <p style={{ fontSize: "12px", fontWeight: "800", letterSpacing: "0.1em", color: "#f59e0b", margin: "0 0 6px", textTransform: "uppercase" }}>{label}</p>
      <p style={{ color: "#94a3b8", fontSize: "14px", margin: 0, lineHeight: "1.7" }}>{value}</p>
    </div>
  );
}
