# Lunda Lesson Plan AI

CBC Lesson Plan Generator for Mushindamo Girl Technical Secondary School.

## How to Deploy to Vercel (Free)

### Option A — Deploy via GitHub (Recommended)

1. Create a free account at https://github.com
2. Create a new repository called `lunda-lesson-plan-ai`
3. Upload all these files to the repository
4. Go to https://vercel.com and sign up (free)
5. Click "New Project" → Import your GitHub repo
6. Click "Deploy" — Vercel does the rest!
7. You'll get a live link like: https://lunda-lesson-plan-ai.vercel.app

### Option B — Deploy via Vercel CLI

1. Install Node.js from https://nodejs.org
2. Open terminal/command prompt
3. Run these commands:
   ```
   npm install -g vercel
   cd lunda-lesson-plan-ai
   vercel
   ```
4. Follow the prompts — you'll get a live URL

## How to Convert to APK

Once your app is live on Vercel:

1. Go to https://webintoapp.com
2. Paste your Vercel URL
3. Enter app name: "Lunda Lesson Plan AI"
4. Upload an icon (optional)
5. Click Generate → Download APK
6. Install the APK on any Android phone

## Project Structure

```
lunda-lesson-plan-ai/
├── public/
│   └── index.html
├── src/
│   ├── App.jsx        ← Main app
│   └── index.js
├── package.json
├── vercel.json
└── README.md
```
